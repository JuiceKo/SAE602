from django.shortcuts import render, redirect
from .models import Message
from .forms import MessageForm
from .nats_utils import send_request_to_nats
import asyncio

def inbox(request):
    messages = Message.objects.all().order_by('-timestamp')
    return render(request, 'messages_app/inbox.html', {'messages': messages})

def send_message(request):
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message_instance = form.save()

            # Send message to NATS
            asyncio.run(send_request_to_nats({'message': message_instance.content}))

            return redirect('inbox')
    else:
        form = MessageForm()

    # Si la requête est de type GET ou si la validation du formulaire échoue, renvoyer la page avec le formulaire
    return render(request, 'messages_app/send_message.html', {'form': form})

def reset_inbox(request):
    if request.method == 'POST':
        # Logique pour réinitialiser la boîte de réception
        Message.objects.all().delete()
        return render(request, 'messages_app/reset_inbox.html')
    else:
        return redirect('inbox')
