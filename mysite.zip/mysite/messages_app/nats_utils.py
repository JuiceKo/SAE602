import json
import asyncio
from nats.aio.client import Client as NATS

async def send_request_to_nats(message):
    nc = NATS()
    await nc.connect(servers=["nats://127.0.0.1:4222"])
    await nc.publish("requete", json.dumps(message).encode())
    await nc.close()
